<?php

require __DIR__ . '/../../payment/frisbee.php';

class ControllerExtensionPaymentFrisbee extends ControllerPaymentFrisbee {}

?>
