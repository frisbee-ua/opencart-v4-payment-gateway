<?php
$_['text_title'] = 'Frsibee';
$_['error_merchant'] = 'An error has occurred during payment. Merchant data is incorrect.';
$_['error_signature'] = 'An error has occurred during payment. Signature is not valid.';
$_['error_transaction'] = 'Transaction has been declined.';
$_['error_frisbee'] = 'Оплата отклонена по причине :';
$_['error_kod'] = 'Код ошибки :';
$_['order_desq'] = 'Оплата заказа №:';
?>
